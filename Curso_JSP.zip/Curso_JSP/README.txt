===========================
Curso de JSP
===========================

I have been following a course:
https://www.youtube.com/watch?v=ed-OyXDxNjM&list=PLU8oAlHdN5BktAXdEVCLUYzvDyqRQJ2lk&index=228

This is a tutorial about JSP - Java Server Pages.
You have 5 examples with the .jsp extension. They are inside the folder 'webapp'.

IMPORTANT: To execute them you need ----------> Apache Tomcat <---------

To run them, if you have the server installed, right click on the
jsp file that you want to run and then Run As > Run on Server > choose you Apache Tomcat Server installation
