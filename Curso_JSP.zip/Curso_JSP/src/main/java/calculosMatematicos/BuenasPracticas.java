package calculosMatematicos;

public class BuenasPracticas {

	/**
	 * Declaramos como static para que sea mas facil llamar a los metodos en el
	 * archivo BuenasPracticas.jsp
	 */

	private static int resultado;

	public static int metodoSuma(int num1, int num2) {

		resultado = num1 + num2;
		return resultado;
	}

	public static int metodoResta(int num1, int num2) {

		resultado = num1 - num2;
		return resultado;
	}

	public static int metodoMultiplica(int num1, int num2) {

		resultado = num1 * num2;
		return resultado;
	}
}
