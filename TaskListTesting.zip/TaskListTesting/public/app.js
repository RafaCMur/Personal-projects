/**
 * TODO https://www.youtube.com/watch?v=Ttf3CEsEwMQ
 * 
 */


//Selectors
const todoInput = document.querySelector('.todo-input');
const todoButton = document.querySelector('.todo-button');
const todoList = document.querySelector('.todo-list');
const filterOption = document.querySelector('.filter-todo');


//Event Listeners
todoButton.addEventListener('click', addTodo);
todoList.addEventListener('click', deleteCheck);
filerOption = addEventListener('click', filterTodo);
document.addEventListener('DOMContentLoaded', getTodosFromLS);


//Functions

function addTodo(event) {
    //Prevent form from submitting and prevents that the browser refreshes
    event.preventDefault();
    //We are going to create a <div></div> tag with the atribute class="todo"
    const todoDiv = document.createElement('div');
    todoDiv.classList.add('todo');
    //Create LI
    const newTodo = document.createElement('li');
    newTodo.innerText = todoInput.value; //The text of the task is what we put in the input field
    newTodo.classList.add('todo-item');
    todoDiv.appendChild(newTodo); //We put the LI element into our DIV
    //ADD TODO TO LOCAL STORAGE
    saveLocalTodos(todoInput.value);
    //CHECK MARK BUTTON
    const completedButton = document.createElement('button');
    completedButton.innerHTML = '<i class="fas fa-check"></i>';
    completedButton.classList.add('complete-btn');
    todoDiv.appendChild(completedButton);
    //CHECK TRASH BUTTON
    const trashButton = document.createElement('button');
    trashButton.innerHTML = '<i class="fas fa-trash"></i>';
    trashButton.classList.add('trash-btn');
    todoDiv.appendChild(trashButton);
    //Append to list <ul></ul> in index.html
    todoList.appendChild(todoDiv);
    //Clear Todo INPUT value
    todoInput.value = '';
}


function deleteCheck(e) {
    const item = e.target;
    //DELETE MARK
    if (item.classList[0] === 'trash-btn') {
        const todo = item.parentElement; //We take the parent of the button which is a task itself
        //Animation
        todo.classList.add("fall");
        removeLocalTodos(todo);
        todo.addEventListener('transitionend', () => {
            todo.remove();
        });
    }

    //CHECK MARK
    if (item.classList[0] === 'complete-btn') {
        const todo = item.parentElement; //We take the parent of the button which is a task itself
        todo.classList.toggle('completed'); //We change the atribute class to 'completed and then we are going to style that class in the css file
        //so that we get the task "tachada in spanish" and a bit grey
    }
}


function filterTodo(e) {
    const todos = todoList.childNodes;
    todos.forEach((todo) => {
        switch (e.target.value) {

            case "all":
                todo.style.display = "flex";
                break;

            case "completed":
                if (todo.classList.contains("completed")) {
                    todo.style.display = 'flex';
                } else {
                    todo.style.display = 'none';
                }
                break;

            case "uncompleted":
                if (!todo.classList.contains("completed")) {
                    todo.style.display = 'flex';
                } else {
                    todo.style.display = 'none';
                }
                break;
        }
    });
}


/**
 * Add a todo to the local storage
 */
function saveLocalTodos(todo) {

    let todos = null;

    //CHECK---HEY! Do I already have things in the local storage?
    if (localStorage.getItem('todos') === null) { //If there are not todos
        todos = [];
    } else {
        todos = JSON.parse(localStorage.getItem('todos'));
    }

    todos.push(todo);
    localStorage.setItem('todos', JSON.stringify(todos));
}

function removeLocalTodos(todo){
    let todos = null;

    //CHECK---HEY! Do I already have things in the local storage?
    if (localStorage.getItem('todos') === null) { //If there are not todos
        todos = [];
    } else {
        todos = JSON.parse(localStorage.getItem('todos'));
    }
    const todoText = todo.children[0].innerText; //We get the text
    const todoIndex = todos.indexOf(todoText);
    todos.splice(todoIndex, 1); //I want to remove the todo's in the array starting with "todoIndex" and I want to remove 1 of them (So it is like a normal remove)
    localStorage.setItem('todos', JSON.stringify(todos));
}

/**
 * Gets the todos from the local storage
 */
function getTodosFromLS() {
    let todos = null;

    //CHECK---HEY! Do I already have things in the local storage?
    if (localStorage.getItem('todos') === null) { //If there are not todos
        todos = [];
    } else {
        todos = JSON.parse(localStorage.getItem('todos'));
    }

    todos.forEach((todo) => {
        //We are going to create a <div></div> tag with the atribute class="todo"
        const todoDiv = document.createElement('div');
        todoDiv.classList.add('todo');
        //Create LI
        const newTodo = document.createElement('li');
        newTodo.innerText = todo; //The text of the task is what we put in the input field
        newTodo.classList.add('todo-item');
        todoDiv.appendChild(newTodo); //We put the LI element into our DIV
        //CHECK MARK BUTTON
        const completedButton = document.createElement('button');
        completedButton.innerHTML = '<i class="fas fa-check"></i>';
        completedButton.classList.add('complete-btn');
        todoDiv.appendChild(completedButton);
        //CHECK TRASH BUTTON
        const trashButton = document.createElement('button');
        trashButton.innerHTML = '<i class="fas fa-trash"></i>';
        trashButton.classList.add('trash-btn');
        todoDiv.appendChild(trashButton);
        //Append to list <ul></ul> in index.html
        todoList.appendChild(todoDiv);
    });
}

