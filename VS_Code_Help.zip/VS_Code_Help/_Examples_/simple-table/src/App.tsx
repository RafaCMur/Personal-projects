import React, { useEffect, useState } from "react";
import "./App.css";

const PLAYERS = [
  { name: "Rafa Nadal", team: "A" },
  { name: "Roger Federer", team: "B" },
  { name: "Andrei", team: "C" },
];

function App() {
  const [active, setActive] = useState(0);

  const renderPlayer = (player: any, index: number) => {
    return (
      <tr
        key={"moviesTable_" + index}
        className={active === index ? "active-row" : "inactive-row"}
        onClick={() => setActive(index)}
      >
        <td>{player.name}</td>
        <td>{player.team}</td>
      </tr>
    );
  };

  useEffect(() => {}, [active]);

  return (
    <div className="App">
      <table className="content-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Team</th>
          </tr>
        </thead>

        <tbody>{PLAYERS.map(renderPlayer)}</tbody>
      </table>
    </div>
  );
}

export default App;
