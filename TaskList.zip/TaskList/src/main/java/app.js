/**
 * TODO
 */


//Selectors and global variables
const taskButton = document.querySelector('.task-button');
const taskTable = document.querySelector('.task-table');
const taskCounter = document.querySelector('.task-counter');
let rowsCounter = 0;
let headerCreated = false;


//Event Listeners
taskButton.addEventListener('click', addTask);
taskTable.addEventListener('click', removeTask);
taskTable.addEventListener('click', handleStatusChange);


//Functions

function addTask(event) {

    const input = prompt();
    
    if (input != null) {
        //Prevent form from submitting and prevents that the browser refreshes
        event.preventDefault();

        //We create the DIV tag
        const taskTr = document.createElement('tr');
        taskTr.classList.add('task-row');

        //Create the header for the first time
        createTh(taskTr);

        //Create TD tag (Cell of the table)
        createInputTextCell(input, taskTr)
        createStatusTextCell(taskTr);
        createSelectCell(taskTr);
        createRemoveBtnCell(taskTr);

        //We add the DIV, which is a row, to the list
        taskTable.appendChild(taskTr);
        incrementCounter();
    }
}


function createTh() {

    //If we have created any task (or any row, a task is a row), then TODO
    if (!headerCreated) {
        const firstTr = document.createElement('tr');
        firstTr.classList.add('task-row-header');

        //Create TH cells
        const thElem = document.createElement('th');
        thElem.classList.add('th-cell');
        thElem.innerText = 'Task';
        firstTr.appendChild(thElem);

        const thElem1 = document.createElement('th');
        thElem1.classList.add('th-cell');
        thElem1.innerText = 'Status';
        firstTr.appendChild(thElem1);

        const thElem2 = document.createElement('th');
        thElem2.classList.add('th-cell');
        thElem2.innerText = '';
        firstTr.appendChild(thElem2);

        //Append th elements to a row, and everything to the table
        taskTable.appendChild(firstTr);

        //We dont want to create another header, so we put headerCreated to true
        headerCreated = true;
    }
}


function createInputTextCell(input, taskTr) {
    //Create text cell and associate the text value to the input
    const textCell = document.createElement('td');
    textCell.classList.add('task-cell');
    textCell.classList.add('task-text-cell');
    textCell.innerText = input;
    taskTr.appendChild(textCell);
}


function createStatusTextCell(taskTr) {
    //Create text cell and associate the text value to the select status
    const textCell = document.createElement('td');
    textCell.classList.add('task-cell');
    textCell.classList.add('task-text-cell');
    textCell.innerText = '<Modify>';
    taskTr.appendChild(textCell);
}


function createSelectCell(taskTr) {
    const newCell = document.createElement('td');
    newCell.classList.add('task-cell');

    const mySelect = document.createElement('select');
    mySelect.classList.add('select-status');

    const modifyOpt = document.createElement('option');
    modifyOpt.innerText = '<Modify>';
    modifyOpt.defaultSelected = true; //This is the default option
    const activeOpt = document.createElement('option');
    activeOpt.innerText = 'ACTIVE';
    const doneOpt = document.createElement('option');
    doneOpt.innerText = 'DONE';

    mySelect.appendChild(modifyOpt);
    mySelect.appendChild(activeOpt);
    mySelect.appendChild(doneOpt);
    newCell.appendChild(mySelect);
    taskTr.appendChild(newCell);
}


function createRemoveBtnCell(taskTr) {
    const newCell2 = document.createElement('td');
    newCell2.classList.add('task-cell');

    const removeBtn = document.createElement('button');
    removeBtn.innerHTML = '<i class="fas fa-trash"> Remove</i>';
    removeBtn.classList.add('remove-btn');
    newCell2.appendChild(removeBtn);
    taskTr.appendChild(newCell2);
}


function removeTask(e) {
    const item = e.target.parentElement;  //We take the button into the variable item

    //Is this the remove-btn?
    if (item.classList[0] === 'remove-btn' && confirm('Do you really want to delete the task?')) {
        const trElem = item.parentElement.parentElement; //We take the parent of the button which is a task itself (a row of the table)
        trElem.remove();
        decrementCounter();
    }
}


function handleStatusChange(e) {
    const selectElem = e.target.parentElement;

    //Is this the select field for selecting the status?
    if (selectElem.classList[0] === 'select-status') {
        resetSelectToDefault(selectElem);
        if (confirm(`Do you want to set the task ${selectElem.parentElement.parentElement.childNodes[0].innerText} to ${e.target.innerText}?`)) {
            //item.parentElement.parentElement is a task (a row).
            console.log('HEY');
            changeStatusTextValue(e.target.innerText, selectElem.parentElement.parentElement);
        }
        resetSelectToDefault(selectElem);
    }
}

/* This module resets the default value a given select element to its default.
 * PRE: You have to set the default option before using:
 * -> myOption.defaultSelected = true;
 */
function resetSelectToDefault(selectElem) {
    let options = selectElem.options;

    for (var i = 0, iLen = options.length; i < iLen; i++) {

        if (options[i].defaultSelected) {
            selectElem.selectedIndex = i;
            return;
        }
    }
    selectElem.selectedIndex = 0; //If something fails, we take the first option as the default
}

/**
 * This method takes a task (a row) and modifies its status. It takes what you select in the
 * select field (ACTIVE, DONE...) and it puts it into the text field.
 * @param text is the text to be used to modify the status text field value
 * @param row is the task to modify
 */
function changeStatusTextValue(text, row) {
    //.childNodes[1] is the status text field
    row.childNodes[1].innerText = text;
}


function incrementCounter() {
    rowsCounter++;
    taskCounter.innerText = `Found ${rowsCounter} tasks`;
};


function decrementCounter() {
    rowsCounter--;

    if (rowsCounter === 0) {
        taskCounter.innerText = `No tasks were found`;
    } else {
        taskCounter.innerText = `Found ${rowsCounter} tasks`;
    }
};