============================================
Curso de MVC (Modelo Vista-Controlador)
============================================

En este proyecto necesitamos las librerias de jstl dentro de la carpeta lib del proyecto.


Course
------
I have been following this course:
https://www.youtube.com/watch?v=H5A5eXbyPxM&list=PLU8oAlHdN5BktAXdEVCLUYzvDyqRQJ2lk&index=248